<?php
  $shortlinks = parse_ini_file("go/shortlinks.ini"); // Получаем массив данных из INI-файла
  if(isset($_GET["go"]) && array_key_exists($_GET["go"], $shortlinks)) { // Если передан правильный GET-параметр
    header("Location: ".$shortlinks[$_GET["go"]]); // Делаем редирект
    exit; // Завершаем скрипт
  } else {
    header("Location: "."/"); // Делаем редирект
  }
?>