<?php
header("Location: "."/public/"); // Делаем редирект
?>